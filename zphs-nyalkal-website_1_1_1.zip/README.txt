Place your logo as assets/logo.png and your building photo as assets/banner.jpg.
Upload this folder to GitHub Pages, Netlify, or any web host.
